﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DataImport.WebSite
{
    public partial class _Default : System.Web.UI.Page
    {
        public static string TableName = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            this.tName.Text = _Default.TableName; 
        }
    }
}